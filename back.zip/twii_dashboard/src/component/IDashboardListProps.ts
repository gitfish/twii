import { IDashboardList } from "../model/IDashboardList";

interface IDashboardListProps {
    dashboardList: IDashboardList;
}

export { IDashboardListProps }