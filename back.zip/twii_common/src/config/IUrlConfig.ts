interface IUrlConfig {
    baseUrl: string;
}

export { IUrlConfig as default, IUrlConfig }