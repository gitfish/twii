interface IHandle<T> {
    value?: T;
    ref?: T;
}

export { IHandle as default, IHandle }; 