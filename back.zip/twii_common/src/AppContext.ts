import { Context } from "./Context";
import { IApp } from "./IApp";

const AppContext = new Context<IApp>({
    id: "app"
});

export { AppContext as default, AppContext }