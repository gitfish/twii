interface ISearchResultValue {
    field: string;
    value: string;
    highlight?: string;
}

export { ISearchResultValue }