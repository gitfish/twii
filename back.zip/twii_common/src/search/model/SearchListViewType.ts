enum SearchListViewType {
    LIST = "LIST",
    DETAILS_LIST = "DETAILS_LIST"
}

export { SearchListViewType }