enum SearchGroupOperator {
    AND = "AND",
    OR = "OR"
}

export { SearchGroupOperator }