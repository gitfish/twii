interface IPathTemplateOptions {
    sensitive?: boolean;
    strict?: boolean;
    end?: boolean;
    delimiter?: string;
};

export { IPathTemplateOptions }