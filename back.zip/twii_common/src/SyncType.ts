enum SyncType {
    create,
    read,
    update,
    delete
}

export { SyncType as default, SyncType };