import { Context } from "@twii/common/lib/Context";
import { IStorageService } from "@twii/common/lib/service/IStorageService";

const DashboardStorageServiceContext = new Context<IStorageService>();

export { DashboardStorageServiceContext }