import MasterEntitySearchServiceContext from "@twii/entity/lib/entity/MasterEntitySearchServiceContext";
import MockMasterEntitySearchService from "@twii/entity/lib/entity/MockMasterEntitySearchService";
import MasterEntityDataServiceContext from "@twii/entity/lib/entity/MasterEntityDataServiceContext";
import MockMasterEntityDataService from "@twii/entity/lib/entity/MockMasterEntityDataService";
import IATServiceContext from "@twii/entity/lib/iat/IATServiceContext";
import MockIATService from "@twii/entity/lib/iat/MockIATService";
import BAGSServiceContext from "@twii/entity/lib/bags/BAGSServiceContext";
import MockBAGSService from "@twii/entity/lib/bags/MockBAGSService";
import EXAMSServiceContext from "@twii/entity/lib/exams/EXAMSServiceContext";
import MockEXAMSService from "@twii/entity/lib/exams/MockEXAMSService";
import DGMSServiceContext from "@twii/entity/lib/dgms/DGMSServiceContext";
import MockDGMSService from "@twii/entity/lib/dgms/MockDGMSService";
import AirCargoServiceContext from "@twii/entity/lib/cargo/air/AirCargoServiceContext";
import MockAirCargoService from "@twii/entity/lib/cargo/air/MockAirCargoService";
import SeaCargoServiceContext from "@twii/entity/lib/cargo/sea/SeaCargoServiceContext";
import MockSeaCargoService from "@twii/entity/lib/cargo/sea/MockSeaCargoService";
import MockIATAService from "@twii/entity/lib/iata/MockIATAService";
import IATAServiceContext from "@twii/entity/lib/iata/IATAServiceContext";
import MockINTCPService from "@twii/entity/lib/intcp/MockINTCPService";
import INTCPServiceContext from "@twii/entity/lib/intcp/INTCPServiceContext";
import { ABRServiceContext } from "@twii/entity/lib/abr/service/ABRServiceContext";
import { MockABRService } from "@twii/entity/lib/abr/service/MockABRService";
import TransientStorageService from "@twii/common/lib/TransientStorageService";
import LoggingStorageService from "@twii/common/lib/LoggingStorageService";
import StorageServiceContext from "@twii/common/lib/StorageServiceContext";
import { DashboardStorageServiceContext } from "../service/DashboardStorageServiceContext";
import { DashboardStorageServiceContext as EntityDashboardStorageContext } from "@twii/entity/lib/common/DashboardStorageServiceContext";
import {MockVisaHistoryCaseSummaryService} from "@twii/matcheval/lib/me/visahistory/MockVisaHistoryCaseSummaryService";
import {VisaHistoryServiceContext} from "@twii/matcheval/lib/me/visahistory/VisaHistoryServiceContext";
import { UserAdminContext } from "@twii/ozone/lib/user/UserAdminContext";
import { UserServiceContext } from "@twii/ozone/lib/user/service/UserServiceContext";
import { MockUserService } from "@twii/ozone/lib/user/service/MockUserService";
import { UserDataServiceContext } from "@twii/ozone/lib/user/service/UserDataServiceContext";
import { MockUserDataService } from "@twii/ozone/lib/user/service/MockUserDataService";
import { isMemberOfGroup } from "@twii/ozone/lib/user/UserHelper";
import { ListingServiceContext } from "@twii/ozone/lib/listing/service/ListingServiceContext";
import { MockListingService, nextListingId, nextListingBookmarkid } from "@twii/ozone/lib/listing/service/MockListingService";
import { ImageServiceContext } from "@twii/ozone/lib/media/service/ImageServiceContext";
import { MockImageService } from "@twii/ozone/lib/media/service/MockImageService";
import { CategoryServiceContext } from "@twii/ozone/lib/category/service/CategoryServiceContext";
import { MockCategoryService } from "@twii/ozone/lib/category/service/MockCategoryService";
import UserGroup from "user/UserGroup";
import { ListingApprovalStatus } from "@twii/ozone/lib/listing/ListingApprovalStatus";
import { IListing } from "@twii/ozone/lib/listing/IListing";
import { configure as commonConfigure } from "./common";
import { EntitySearchServiceContext } from "@twii/entity/lib/search/service/EntitySearchServiceContext";
import { MockEntitySearchService } from "@twii/entity/lib/search/service/MockEntitySearchService";
import { EntityPhotosServiceContext } from "@twii/entity/lib/entityphotos/service/EntityPhotosServiceContext";
import { MockEntityPhotosService } from "@twii/entity/lib/entityphotos/service/MockEntityPhotosService";

const configure = (env : any) => {
    console.log("-- Applying Mock Configuration");

    commonConfigure(env);
    
    // ozone config
    // admin context
    UserAdminContext.value = userProfile => {
        return isMemberOfGroup(userProfile, UserGroup.ADMIN);
    };
    const userService = new MockUserService();
    userService.userProfile = {
        id: 1,
        display_name: "Mock User",
        bio: "Mock User Bio",
        user: {
            username: "mock",
            email: "mock@ande.dev",
            groups: [
                {
                    name: "USER"
                },
                {
                    name: "APPS_MALL_STEWARD"
                },
                {
                    name: "analyst_desktop_entity_search"
                },
                {
                    name: "analyst_desktop_match_evaluation"
                },
                {
                    name: "analyst_desktop_risk_resume"
                }
            ]
        }
    }
    UserServiceContext.value = userService;
    UserDataServiceContext.value = new MockUserDataService();
    const listingService = new MockListingService();
    const listings : IListing[] = [
        {
            id: nextListingId(),
            unique_name: "entity.search",
            title: "Entity Search",
            description: "Entity Search",
            description_short: "Entity Search",
            launch_url: "/entity/search",
            security_marking: "analyst_desktop_entity_search",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "new.entity.search",
            title: "New Entity Search",
            description: "New Entity Search",
            description_short: "New Entity Search",
            launch_url: "/entity/search/new",
            security_marking: "analyst_desktop_entity_search",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "entity.profile",
            title: "Clipboard",
            description: "Clipboard",
            description_short: "Clipboard",
            launch_url: "/entity/profile",
            security_marking: "analyst_desktop_entity_search",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "vra.search",
            title: "Risk Resume",
            description: "Risk Resume",
            description_short: "Risk Resume",
            launch_url: "/vra/search",
            security_marking: "analyst_desktop_risk_resume",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "me.casemanagement",
            title: "ME Case Management",
            description: "ME Case Management",
            description_short: "ME Case Management",
            launch_url: "/me/portal",
            security_marking: "analyst_desktop_match_evaluation",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "itm.portal",
            title: "ITM Portal",
            description: "ITM Portal",
            description_short: "ITM Portal",
            launch_url: "https://e6-portals.immi.gov.au/protectedportal",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "itm.reporting",
            title: "ITM Reporting",
            description: "ITM Reporting",
            description_short: "ITM Reporting",
            launch_url: "http://birs-st/BOE/BI",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "match.eval.search",
            is_enabled: true,
            title: "Match Eval Search",
            launch_url: "/me/search",
            security_marking: "analyst_desktop_match_evaluation",
            approval_status: ListingApprovalStatus.APPROVED
        }, {
            id: nextListingId(),
            unique_name: "irp",
            is_enabled: true,
            title: "Integrated Risk Portal",
            launch_url: "/irp/search",
            security_marking: "analyst_desktop_match_evaluation",
            approval_status: ListingApprovalStatus.APPROVED
        }, {
            id: nextListingId(),
            unique_name: "pnr.search",
            is_enabled: true,
            title: "PNR Search",
            launch_url: "/pnrsearch/search",
            security_marking: "analyst_desktop_match_evaluation",
            approval_status: ListingApprovalStatus.APPROVED
        }
    ];
    const bookmarks = listings.map(l => {
        return {
            id: nextListingBookmarkid(),
            listing: l
        };
    });
    listingService.listings = listings;
    listingService.bookmarks = bookmarks;
    ListingServiceContext.value = listingService;
    ImageServiceContext.value = new MockImageService();
    CategoryServiceContext.value = new MockCategoryService();

    MasterEntitySearchServiceContext.value = new MockMasterEntitySearchService();
    MasterEntityDataServiceContext.value = new MockMasterEntityDataService();
    IATServiceContext.value = new MockIATService();
    BAGSServiceContext.value = new MockBAGSService();
    EXAMSServiceContext.value = new MockEXAMSService();
    DGMSServiceContext.value = new MockDGMSService();
    AirCargoServiceContext.value = new MockAirCargoService();
    SeaCargoServiceContext.value = new MockSeaCargoService();
    IATAServiceContext.value = new MockIATAService();
    INTCPServiceContext.value = new MockINTCPService();
    ABRServiceContext.value = new MockABRService();
    StorageServiceContext.value = new TransientStorageService();
    const dashboardStorageService = new LoggingStorageService(new TransientStorageService(), "mockStorage");
    DashboardStorageServiceContext.value = dashboardStorageService;
    EntityDashboardStorageContext.value = dashboardStorageService;
    EntitySearchServiceContext.value = new MockEntitySearchService();
    const photosService = new MockEntityPhotosService();
    //photosService.photos = [];
    EntityPhotosServiceContext.value = photosService;

    // ME Visa History
    VisaHistoryServiceContext.value = new MockVisaHistoryCaseSummaryService();

};

export { configure, configure as default };