import { ITheme, concatStyleSets, FontSizes, FontWeights } from "@uifabric/styling";
import { Defaults as AppViewStyleDefaults, defaultStyles as appViewDefaultStyles } from "@twii/common/lib/component/AppView.styles";
import { Defaults as StackStyleDefaults, defaultStyles as stackDefaultStyles } from "@twii/dashboard/lib/component/Stack.styles";
import { Defaults as WindowStyleDefaults, defaultStyles as windowDefaultStyles } from "@twii/dashboard/lib/component/Window.styles";

const commandBarHeight = 28;

const configure = (env : any) => {
    AppViewStyleDefaults.styles = (theme : ITheme) => {
        return concatStyleSets(appViewDefaultStyles(theme), {
            root: {
                selectors: {
                    ".ms-CommandBar": {
                        height: commandBarHeight,
                        paddingLeft: 0,
                        paddingRight: 0,
                        selectors: {
                            ".ms-CommandBar-primaryCommands": {
                                marginLeft: 0,
                                lineHeight: commandBarHeight,
                                height: commandBarHeight
                            },
                            ".ms-CommandBar-sideCommands": {
                                paddingRight: 0,
                                lineHeight: commandBarHeight,
                                height: commandBarHeight
                            },
                            ".ms-CommandBarItem": {
                                height: commandBarHeight,
                                selectors: {
                                    ".ms-Icon, .ms-Button-icon": {
                                        fontSize: FontSizes.small
                                    },
                                    ".ms-Button": {
                                        lineHeight: commandBarHeight,
                                        height: commandBarHeight,
                                        fontSize: FontSizes.small
                                    },
                                    ".ms-CommandBarItem-link": {
                                        lineHeight: commandBarHeight,
                                        height: commandBarHeight,
                                        fontSize: FontSizes.small
                                    },
                                    ".ms-CommandBarItem-commandText": {
                                        lineHeight: commandBarHeight,
                                        height: commandBarHeight,
                                        fontSize: FontSizes.small
                                    },
                                    ".ms-CommandBarItem-text": {
                                        lineHeight: commandBarHeight,
                                        height: commandBarHeight,
                                        fontSize: FontSizes.small
                                    },
                                    ".ms-CommandBarItem-custom-button": {
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        fontSize: FontSizes.medium,
                                        fontWeight: FontWeights.regular,
                                        color: theme.palette.themeSecondary,
                                        position: "relative",
                                        background: "0 0",
                                        border: "none",
                                        lineHeight: commandBarHeight,
                                        minWidth: 20,
                                        textAlign: "center",
                                        padding: "0 4px",
                                        height: commandBarHeight,
                                        cursor: "pointer",
                                        outline: "transparent",
                                        selectors: {
                                            "&[disabled]": {
                                                color: theme.palette.neutralTertiary
                                            },
                                            ".material-icons": {
                                                padding: "0px 4px"
                                            }
                                        }
                                    },
                                    ".ms-CommandBarItem-icon": {
                                        lineHeight: commandBarHeight,
                                        height: commandBarHeight,
                                        fontSize: FontSizes.icon
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
    }

    StackStyleDefaults.styles = (theme : ITheme) => {
        return concatStyleSets(stackDefaultStyles(theme), {
            actionBar: {
                backgroundColor: "transparent",
                height: "auto"
            },
            header: {
                backgroundColor: theme.palette.neutralLight,
            },
            tabBar: {
                position: "absolute",
                top: 0,
                right: 0,
                bottom: 0,
                left: 0,
                height: "auto",
                borderBottom: `1px solid ${theme.palette.themeDark}`
            },
            tabTitle: {
                fontSize: FontSizes.small
            },
            tabAction: {
                color: theme.palette.white,
                selectors: {
                    "&.active": {
                        color: theme.palette.white
                    },
                    "&.close-action": {
                        selectors: {
                            ":hover": {
                                color: theme.palette.white,
                                backgroundColor: theme.palette.redDark
                            }
                        }
                    }
                }
            },
            addAction: {
                backgroundColor: theme.palette.themeTertiary,
                color: theme.palette.white,
                marginLeft: 1,
                selectors: {
                    ":hover": {
                        backgroundColor: theme.palette.themeSecondary
                    },
                    "&.stack-add-action-icon": {
                        color: theme.palette.white,
                        fontSize: theme.fonts.medium.fontSize
                    }
                }
            },
            addActionIcon: {
                color: theme.palette.white
            },
            tab: {
                backgroundColor: theme.palette.themeTertiary,
                color: theme.palette.white,
                boxShadow: "none",
                marginLeft: 1,
                selectors: {
                    "&.first": {
                        marginLeft: 0
                    },
                    "&.active": {
                        backgroundColor: theme.palette.themeDarker,
                        color: theme.palette.white,
                        boxShadow: "none",
                        selectors: {
                            ":hover": {
                                backgroundColor: theme.palette.themeDarker,
                                color: theme.palette.white
                            }
                        }
                    },
                    ":hover": {
                        backgroundColor: theme.palette.themeSecondary,
                        color: theme.palette.white
                    }
                }
            },
            body: {
                boxShadow: "none"
            }
        }); 
    }

    WindowStyleDefaults.styles = (theme : ITheme) => {
        return concatStyleSets(windowDefaultStyles(theme), {
            header: {
                backgroundColor: theme.palette.themeDarker
            },
            action: {
                selectors: {
                    ":hover": {
                        backgroundColor: theme.palette.themeDark
                    }
                }
            }
        });
    };
};

export { configure }