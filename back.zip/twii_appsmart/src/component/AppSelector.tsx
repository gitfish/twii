import * as React from "react";
import { UserListingsApp } from "@twii/ozone/lib/listing/component/UserListingsApp";
import { IAppViewStyles } from "@twii/common/lib/component/AppView.styles";
import backgroundImage from "./AppSelectorBackground.png";

class AppSelectorApp extends UserListingsApp {
    protected get appViewStyles() : IAppViewStyles {
        return {
            main: {
                backgroundImage: `url(${backgroundImage})`,
                backgroundRepeat: "no-repeat",
                backgroundPosition: "50% 60%"
            }
        };
    }
    protected get showLinks() : boolean { 
        return true;
    }
}

export {
    AppSelectorApp,
    AppSelectorApp as default
}