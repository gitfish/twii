import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";

class Help extends React.Component<any, any> {
    render() {
        return (
            <div>
                <div className="default-help">
                    <p>
                        <strong>Appsmart</strong> provides a customisable workspace featuring a range of apps that can be added or removed according to your needs.
                    </p>
                </div>
            </div>
        );
    }
}

class HelpApp extends React.Component<IAppProps, any> {
    componentWillMount() {
        this.props.match.host.setTitle("Appsmart Help");
    }
    render() {
        return <Help />;
    }
}

export { HelpApp, HelpApp as default, Help }