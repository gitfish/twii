import "core-js";
import * as React from "react";
import * as ReactDOM from "react-dom";
import { BrowserAppHost } from "@twii/common/lib/model/BrowserAppHost";
import { AppHostContainer } from "@twii/common/lib/component/AppHost";
import AppContext from "@twii/common/lib/AppContext";
import AppRouter from "./AppRouter";
import { Fabric } from "office-ui-fabric-react/lib/Fabric";
import { initializeIcons } from "@uifabric/icons";
import "index.scss";

const host = new BrowserAppHost();
host.setRoot(true);
host.window = window;
host.router = AppRouter;
host.publicPath = AppConfig.basePath;

AppContext.value = {
    config: AppConfig,
    router: AppRouter,
    rootAppHost: host
};

// fabric icon initialization
initializeIcons(AppConfig.fabricIconBasePath);

const main = document.createElement("div");
main.id = "main";
document.body.appendChild(main);

// render
ReactDOM.render(
    <Fabric className="analyst-desktop">
        <AppHostContainer host={host} />
    </Fabric>,
    main
);
