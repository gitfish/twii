import { Context } from "@twii/common/lib/Context";
import { ICategoryService } from "./ICategoryService";

const CategoryServiceContext = new Context<ICategoryService>();

export { CategoryServiceContext }