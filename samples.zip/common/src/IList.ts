interface IList<T = any> {
    items: T[];
}

export { IList }