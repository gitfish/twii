import { memoizeFunction } from "@uifabric/utilities";
import { IPillStyles } from "./Pill.styles";
import { mergeStyleSets } from "@uifabric/styling";

interface IPillClassNames {
    root?: string;
}

const getClassNames = memoizeFunction((styles : IPillStyles, className?: string) : IPillClassNames => {
    return mergeStyleSets({
        root: ["pill", styles.root, className]
    })
});

export { IPillClassNames, getClassNames }