import * as React from "react";
import { observer } from "mobx-react";
import { Overlay, IOverlayProps } from "office-ui-fabric-react/lib/Overlay";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import { ISync } from "../ISync";
import { ISyncOverlayStyles, getStyles } from "./SyncOverlay.styles";
import { ISyncOverlayClassNames, getClassNames } from "./SyncOverlay.classNames";

interface ISyncOverlayProps {
    sync: ISync;
    syncLabel?: string;
    onRenderSync?: (props : ISyncOverlayProps) => React.ReactNode;
    onRenderError?: (props : ISyncOverlayProps) => React.ReactNode;
    styles?: ISyncOverlayStyles;
    className?: string;
    overlayProps?: IOverlayProps;
}

const defaultRenderSync = (props : ISyncOverlayProps) => {
    return <Spinner label={props.syncLabel || "Loading..."} />
};

@observer
class SyncOverlay extends React.Component<ISyncOverlayProps, any> {
    render() {
        const { sync, onRenderSync, onRenderError, styles, className, overlayProps } = this.props;
        if(sync.syncing || (onRenderError && sync.error)) {
            const classNames = getClassNames(getStyles(null, styles), className);
            const content = sync.error ? onRenderError(this.props) : (onRenderSync || defaultRenderSync)(this.props);
            return (
                <Overlay {...overlayProps} className={classNames.root}>
                    <div className={classNames.content}>{content}</div>
                </Overlay>
            );
        }
        return null;
    }
}

export { ISyncOverlayProps, SyncOverlay }