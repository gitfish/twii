import * as React from "react";
import { getClassNames } from "./Pill.classNames";
import { getStyles, IPillStyles } from "./Pill.styles";
import { Link, ILinkProps } from "office-ui-fabric-react/lib/Link";
import { css } from "@uifabric/utilities";

interface IPillProps extends ILinkProps {
    onClick?: (e : React.MouseEvent<HTMLButtonElement>) => void;
    title?: string;
    styles?: IPillStyles;
    className?: string;
}

class Pill extends React.Component<IPillProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        const view = (
            <div className={css(classNames.root, { clickable: this.props.onClick ? true : false })} title={this.props.title}>
                {this.props.children}
            </div>
        );
        return this.props.onClick ? <Link {...this.props}>{view}</Link> : view;
    }
}

export { Pill, IPillProps }