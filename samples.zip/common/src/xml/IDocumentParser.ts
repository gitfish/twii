interface IDocumentParser {
    parseDocument(source : string) : Document;
}

export { IDocumentParser as default, IDocumentParser }