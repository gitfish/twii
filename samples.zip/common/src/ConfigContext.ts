import { Context } from "./Context";

const ConfigContext = new Context<any>();

export { ConfigContext }