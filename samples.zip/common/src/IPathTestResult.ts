interface IPathTestResult {
    match: boolean;
    params?: any;
}

export { IPathTestResult };