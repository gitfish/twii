interface ISearchField {
    name: string;
    searchString: string;
}

export { ISearchField }