interface ISearchSchemaField {
    key: string;
    name?: string;
    fields?: string[];
    aliases?: string[];
    hidden?: boolean;
}

interface ISearchSchema {
    fields: ISearchSchemaField[]
}

export { ISearchSchemaField, ISearchSchema }