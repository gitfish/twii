import { IStyle, ITheme, getTheme, FontSizes, FontWeights } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";
import { concatStyleSets } from "@uifabric/merge-styles";

interface ISearchableValueStyles {
    root?: IStyle;
}

const defaultStyles = (theme : ITheme) : ISearchableValueStyles => {
    return {
        root: {
            display: "block",
            border: "none",
            padding: "2px 4px",
            marginTop: 2,
            marginBottom: 2,
            selectors: {
                "&.clickable": {
                    cursor: "pointer",
                    background: theme.palette.white,
                    outline: "none",
                    textAlign: "left",
                    selectors: {
                        "&:hover": {
                            textDecoration: "underline"
                        }
                    }
                }
            }
        }
    }
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles?: ISearchableValueStyles) : ISearchableValueStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export { ISearchableValueStyles, getStyles, defaultStyles, Defaults }