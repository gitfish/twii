import { IStyle, ITheme, getTheme, concatStyleSets } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface ISearchRequestSummaryStyles {
    root?: IStyle;
    op?: IStyle;
    group?: IStyle;
    value?: IStyle;
}

const defaultStyles = (theme : ITheme) : ISearchRequestSummaryStyles => {
    return {
        root: {
            display: "flex",
            alignItems: "center"
        },
        op: {
            padding: 4,
            borderRadius: 4,
            backgroundColor: theme.palette.neutralTertiary,
            color: theme.palette.white,
            fontSize: theme.fonts.small.fontSize
        },
        group: {
            display: "flex",
            alignItems: "center",
            padding: 4,
            borderRadius: 4,
            marginLeft: 8,
            marginTop: 2,
            marginBottom: 2,
            border: `1px solid ${theme.palette.neutralQuaternary}`
        },
        value: {
            paddingLeft: 8
        }
    }
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles?: ISearchRequestSummaryStyles) : ISearchRequestSummaryStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export {
    ISearchRequestSummaryStyles,
    defaultStyles,
    Defaults,
    getStyles
}