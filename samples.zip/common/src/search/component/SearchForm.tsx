import * as React from "react";
import { ISearchFieldModel } from "../model/ISearchFieldModel";
import { observer } from "mobx-react";
import { ISearchFormStyles, getStyles } from "./SearchForm.styles";
import { getClassNames } from "./SearchForm.classNames";
import { IDropdownOption, Dropdown } from "office-ui-fabric-react/lib/Dropdown";
import { BoundTextField } from "../../component/BoundTextField";
import { IconButton, PrimaryButton, DefaultButton, CommandBarButton, IButtonProps } from "office-ui-fabric-react/lib/Button";
import { ISearchRequest } from "../ISearchRequest";
import { ISearchRequestProps } from "./ISearchRequestProps";
import { SearchGroupOperator } from "../SearchGroupOperator";
import { KeyCodes, css } from "@uifabric/utilities";
import { BoundSearchBox } from "../../component/BoundSearchBox";
import { ISearchGroupModel } from "../model/ISearchGroupModel";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { getSchemaField } from "../SearchHelper";
import { ISearchGroup } from "../ISearchGroup";

interface ISearchFormProps extends ISearchRequestProps {
    styles?: ISearchFormStyles;
    className?: string;
    onSubmit?: (request : ISearchRequest) => void;
    hideOperator?: boolean;
    hideTextExpand?: boolean;
    textPlaceholder?: string;
}

interface ISearchGroupProps {
    group: ISearchGroupModel;
    styles?: ISearchFormStyles;
    className?: string;
}

interface ISearchGroupFieldProps extends ISearchGroupProps {
    field: ISearchFieldModel;
}

@observer
class SearchGroupFieldSelector extends React.Component<ISearchGroupFieldProps, any> {
    private _onChanged = (option : IDropdownOption) => {
        this.props.field.setName(String(option.key));
    }
    render() {
        const options : IDropdownOption[] = [];
        options.push({
            key: "",
            text: "All Fields"
        });
        this.props.group.schema.fields.forEach(s => {
            if(!s.hidden) {
                options.push({
                    key: s.key,
                    text: s.name || s.key
                });
            }
        });
        const fieldName = this.props.field.name;
        const schemaField = getSchemaField(this.props.group.schema, fieldName);
        const selectedKey = schemaField ? schemaField.key : "";
        return <Dropdown options={options} onChanged={this._onChanged} selectedKey={selectedKey} />;
    }
}

@observer
class SearchGroupFieldValueEditor extends React.Component<ISearchGroupFieldProps, any> {
    render() {
        return <BoundTextField binding={{ target: this.props.field, key: "searchString" }} />;
    }
}

class SearchGroupFieldRemoveAction extends React.Component<ISearchGroupFieldProps, any> {
    private _onClick = () => {
        this.props.field.remove();
    }
    render() {
        return <IconButton onClick={this._onClick} iconProps={{ iconName: "Delete" }} title="Remove Field" ariaLabel="Remove Field" />
    }
}

class SearchGroupField extends React.Component<ISearchGroupFieldProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.fieldContainer}>
                <div className={classNames.fieldSelectContainer}>
                    <SearchGroupFieldSelector {...this.props} />
                </div>
                <div className={classNames.fieldValueContainer}>
                    <SearchGroupFieldValueEditor {...this.props} />
                </div>
                <div className={classNames.fieldRemoveContainer}>
                    <SearchGroupFieldRemoveAction {...this.props} />
                </div>
            </div>
        );
    }
}

class SearchGroupFieldAddAction extends React.Component<ISearchGroupProps, any> {
    private _onClick = () => {
        this.props.group.addField();
    }
    render() {
        return <DefaultButton iconProps={{ iconName: "Add"}} onClick={this._onClick}>Add Rule</DefaultButton>;
    }
}

class SearchGroupGroupAddAction extends React.Component<ISearchGroupProps, any> {
    private _onClick = () => {
        this.props.group.addGroup();
    }
    render() {
        return <DefaultButton iconProps={{ iconName: "Add"}} onClick={this._onClick}>Add Group</DefaultButton>;
    }
}

class SearchGroupAddCommandBarButton extends React.Component<ISearchGroupProps, any> {
    private _onClickAddField = () => {
        this.props.group.addField();
    }
    private _onClickAddGroup = () => {
        this.props.group.addGroup();
    }
    render() {
        const items : IContextualMenuItem[] = [];
        items.push({
            key: "group",
            name: "Add Group",
            iconProps: {
                iconName: "Add"
            },
            onClick: this._onClickAddGroup
        });
        return (
            <CommandBarButton iconProps={{ iconName: "Add" }} menuProps={{ items: items }} split onClick={this._onClickAddField}>
                Add Rule
            </CommandBarButton>
        );
    }
}

const createSearchGroupAddMenuItem = (props : ISearchGroupProps) : IContextualMenuItem => {
    return {
        key: "searchGroupAdd",
        onRender(item) {
            return <SearchGroupAddCommandBarButton key={item.key} {...props} />;
        }
    };
};

@observer
class SearchRequestAddCommandBarButton extends React.Component<ISearchRequestProps, any> {
    render() {
        if(this.props.request.isComplex) {
            return <SearchGroupAddCommandBarButton group={this.props.request} />;
        }
        return null;
    }
};

const createSearchRequestAddMenuItem = (props : ISearchRequestProps) : IContextualMenuItem => {
    return {
        key: "searchRequestAdd",
        onRender(item) {
            return <SearchRequestAddCommandBarButton key={item.key} {...props} />;
        }
    };
};

@observer
class SearchGroupFields extends React.Component<ISearchGroupProps, any> {
    render()  {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        const fieldViews = this.props.group.fields.map((field, idx) => {
            return <SearchGroupField key={idx} {...this.props} field={field} />
        });
        if(fieldViews.length > 0) {
            return (
                <div className={classNames.fieldsContainer}>
                    {fieldViews}
                </div>
            );
        }
        return null;
    }  
}

@observer
class SearchGroupChildGroups extends React.Component<ISearchGroupProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        const groupViews = this.props.group.groups.map((g, idx) => {
            return <SearchGroup key={idx} {...this.props} group={g} />;
        });
        if(groupViews.length > 0) {
            return (
                <div className={classNames.fieldsContainer}>
                    {groupViews}
                </div>
            );
        }
        return null;
    }
}

@observer
class SearchGroupFieldActions extends React.Component<ISearchGroupProps, any> {
    render() {
        return (
            <div>
                <SearchGroupFieldAddAction {...this.props} />
                {this.props.group.groups.length === 0 && <SearchGroupGroupAddAction {...this.props} />}
            </div>
        );
    }
}

@observer
class SearchGroupGroupActions extends React.Component<ISearchGroupProps, any> {
    render() {
        if(this.props.group.groups.length > 0) {
            return <SearchGroupGroupAddAction {...this.props} />;
        }
        return null;
    }
}

@observer
class SearchGroupRemoveCommandBarButton extends React.Component<ISearchGroupProps, any> {
    private _onClick = () => {
        this.props.group.remove();
    }
    render() {
        if(this.props.group.parent) {
            return (
                <CommandBarButton onClick={this._onClick} iconProps={{ iconName: "Clear" }} title="Remove Group" ariaLabel="Remove Group" />
            );
        }
        return null;
    }
}

const createSearchGroupRemoveMenuItem = (props : ISearchGroupProps) : IContextualMenuItem => {
    return {
        key: "searchGroupRemove",
        onRender(item) {
            return <SearchGroupRemoveCommandBarButton key={item.key} {...props} />;
        }
    }   
}

class SearchGroup extends React.Component<ISearchGroupProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        const items : IContextualMenuItem[] = [];
        items.push(
            createSearchGroupAddMenuItem(this.props),
            createGroupOperatorMenuItem(this.props)
        );
        const farItems : IContextualMenuItem[] = [];
        farItems.push(
            createSearchGroupRemoveMenuItem(this.props)
        );
        return (
            <div className={classNames.childGroup}>
                <CommandBar items={items} farItems={farItems} />
                <div className={classNames.childGroupContent}>
                    <SearchGroupFields {...this.props} />
                    <SearchGroupChildGroups {...this.props} />
                </div>
            </div>
        );
    }  
}

@observer
class SearchFormSubmitButton extends React.Component<ISearchFormProps, any> {
    private _onClick = () => {
        if(this.props.request.isSpecified) {
            this.props.onSubmit(this.props.request.data);
        }
    }
    render() {
        if(this.props.onSubmit) {
            const disabled = !this.props.request.isSpecified;
            return <PrimaryButton iconProps={{ iconName: "Search"}} onClick={this._onClick} disabled={disabled}>Search</PrimaryButton>
        }
        return null;
    }
}

@observer
class SearchFormClearButton extends React.Component<ISearchFormProps, any> {
    private _onClick = () => {
        this.props.request.clear();
    }
    render() {
        if(this.props.onSubmit) {
            const disabled = !this.props.request.isSpecified;
            return <DefaultButton iconProps={{ iconName: "Clear"}} onClick={this._onClick} disabled={disabled}>Clear</DefaultButton>
        }
        return null;
    }
}

class SearchFormActions extends React.Component<ISearchFormProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.searchActions}>
                <SearchFormSubmitButton {...this.props} />
                <SearchFormClearButton {...this.props} />
            </div>
        );
    }
}

@observer
class SearchFormExpandButton extends React.Component<ISearchRequestProps, any> {
    private _onClick = () => {
        this.props.request.setComplex(!this.props.request.isComplex);
    }
    render() {
        const { request } = this.props;
        const iconTitle = request.isComplex ? "Hide Extended Search" : "Show Extended Search";
        return (
            <IconButton onClick={this._onClick}
                        iconProps={{ iconName: request.isComplex ? "ChevronUp" : "ChevronDown" }}
                        title={iconTitle}
                        ariaLabel={iconTitle}
                        styles={{ root: { height: "100%" }}} />
        );
    }
}

class SearchFormTextSearch extends React.Component<ISearchFormProps, any> {
    private _onSearch = () => {
        if(this.props.onSubmit && this.props.request.isSpecified) {
            this.props.onSubmit(this.props.request.data);
        }
    }
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <BoundSearchBox className={classNames.textSearch} binding={{ target: this.props.request, key: "searchString" }} placeholder={this.props.textPlaceholder || "Search"} onSearch={this._onSearch} />
        );
    }
}

@observer
class SearchModeSelectCommandBarButton extends React.Component<ISearchRequestProps, any> {
    private _onClick = (ev, item) => {
        this.props.request.setComplex(item.complex);
    }
    render() {
        const items : IContextualMenuItem[] = [];
        items.push({
            key: "text",
            name: "Text",
            title: "Search using a single text field",
            iconProps: { iconName: "TextField" },
            canCheck: true,
            checked: !this.props.request.isComplex,
            complex: false,
            onClick: this._onClick
        });
        items.push({
            key: "query",
            name: "Query Builder",
            title: "Search using the query builder",
            iconProps: { iconName: "QueryList" },
            canCheck: true,
            checked: this.props.request.isComplex,
            complex: true,
            onClick: this._onClick
        });
        const current = items.find(item => item.checked);
        return (
            <CommandBarButton menuProps={{ items: items }}
                              iconProps={current.iconProps}
                              title={current.title}>
                {current.name}
            </CommandBarButton>
        );
    }
}

const createSearchModeSelectMenuItem = (props : ISearchRequestProps) : IContextualMenuItem => {
    return {
        key: "searchModeToggle",
        onRender: (item) => {
            return <SearchModeSelectCommandBarButton key={item.key} {...props} />;
        }
    };
};

interface ISearchGroupButtonProps extends ISearchGroupProps {
    buttonProps?: IButtonProps;
}

@observer
class GroupOperatorCommandBarButton extends React.Component<ISearchGroupButtonProps, any> {
    private _onClickItem = (e, item) => {
        this.props.group.setOp(item.key);
    }
    render() {
        const { group } = this.props;
        const operator = group.op;
        const items : IContextualMenuItem[] = [
            {
                key: SearchGroupOperator.AND,
                name: SearchGroupOperator.AND,
                value: SearchGroupOperator.AND,
                title: `Apply ${SearchGroupOperator.AND} Operator: results will match all of the specified terms/phrases`,
                ariaLabel: `Apply ${SearchGroupOperator.AND} Operator: results will match all of the specified terms/phrases`,
                onClick: this._onClickItem,
                canCheck: true,
                checked: operator === SearchGroupOperator.AND
            },
            {
                key: SearchGroupOperator.OR,
                name: SearchGroupOperator.OR,
                onClick: this._onClickItem,
                title: `Apply ${SearchGroupOperator.OR} Operator: results will match any of the specified terms/phrases`,
                ariaLabel: `Apply ${SearchGroupOperator.OR} Operator: results will match any of the specified terms/phrases`,
                canCheck: true,
                checked: operator === SearchGroupOperator.OR
            }
        ];
        const current = items.find(item => item.checked);
        return (
            <CommandBarButton menuProps={{ items: items }} title={current.title}>
                {current.name
            }</CommandBarButton>
        );
    }
}

const createGroupOperatorMenuItem = (props : ISearchGroupButtonProps) : IContextualMenuItem => {
    return {
        key: "searchGroupOperator",
        onRender(item) {
            return <GroupOperatorCommandBarButton key={item.key} {...props} />;
        }
    };
};

interface ISearchRequestButtonProps extends ISearchRequestProps {
    buttonProps?: IButtonProps;
}

@observer
class SearchRequestOperatorCommandBarButton extends React.Component<ISearchRequestButtonProps, any> {
    render() {
        if(!this.props.request.isComplex) {
            return <GroupOperatorCommandBarButton {...this.props} group={this.props.request} />
        }
        return null;
    }
}

const createSearchRequestOperatorMenuItem = (props : ISearchRequestButtonProps) : IContextualMenuItem => {
    return {
        key: "searchRequestOperator",
        onRender(item) {
            return <SearchRequestOperatorCommandBarButton key={item.key} {...props} />
        }
    };
};

class SearchFormTextSearchContainer extends React.Component<ISearchFormProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.textSearchContainer}>
                <SearchFormTextSearch {...this.props} />
            </div>
        );
    }
}

@observer
class SearchFormOperator extends React.Component<ISearchFormProps, any> {
    private _onChanged = (option : IDropdownOption) => {
        this.props.request.setOp(option.key as SearchGroupOperator);
    }
    render() {
        if(this.props.request.isComplex && !this.props.hideOperator) {
            const op = this.props.request.op;
            const options : IDropdownOption[] = [
                {
                    key: SearchGroupOperator.AND,
                    text: "AND - results will match all of the specified terms/phrases"
                },
                {
                    key: SearchGroupOperator.OR,
                    text: "OR - results will match any of the specified terms/phrases"
                }
            ];
            const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
            return (
                <div className={classNames.inputContainer}>
                    <Dropdown options={options} selectedKey={op} onChanged={this._onChanged} label="Operator" />
                </div>
            );
        }
        return null;
    }
}

class SearchFormExpandedContainer extends React.Component<ISearchFormProps, any> {
    render() {
        return (
            <div>
                <SearchGroup {...this.props} group={this.props.request} />
                <SearchFormActions {...this.props} />
            </div>
        );
    }
}

@observer
class SearchForm extends React.Component<ISearchFormProps, any> {
    private _onKeyDown = (e : React.KeyboardEvent<HTMLElement>) => {
        if(e.which === KeyCodes.enter && this.props.request.isSpecified) {
            this.props.onSubmit(this.props.request.data);
        }
    }
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.root} onKeyDown={this._onKeyDown}>
                <div className={classNames.content}>
                    {!this.props.request.isComplex && <SearchFormTextSearchContainer {...this.props} />}
                    {this.props.request.isComplex && <SearchFormExpandedContainer {...this.props} />}
                </div>
            </div>
        );
    }
}

export {
    ISearchFormProps,
    ISearchGroupProps,
    ISearchGroupFieldProps,
    SearchGroupFields,
    SearchGroupField,
    SearchFormTextSearch,
    SearchFormTextSearchContainer,
    SearchFormOperator,
    SearchFormActions,
    SearchForm,
    SearchModeSelectCommandBarButton,
    createSearchModeSelectMenuItem,
    GroupOperatorCommandBarButton,
    createGroupOperatorMenuItem,
    SearchGroupAddCommandBarButton,
    createSearchGroupAddMenuItem,
    SearchRequestAddCommandBarButton,
    createSearchRequestAddMenuItem,
    SearchRequestOperatorCommandBarButton,
    createSearchRequestOperatorMenuItem
}