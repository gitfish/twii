import { IStyle, ITheme, getTheme, FontSizes, FontWeights } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";
import { concatStyleSets } from "@uifabric/merge-styles";

interface ISearchResultStyles {
    root?: IStyle;
    additional?: IStyle;
    value?: IStyle;
}

const defaultStyles = (theme : ITheme) : ISearchResultStyles => {
    return {
        root: {
            selectors: {
                "&.flex": {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "flex-start",
                    flexWrap: "wrap",
                    lineHeight: FontSizes.medium,
                    selectors: {
                        "$additional": {
                            padding: 8,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "flex-start",
                            flexWrap: "wrap",
                            lineHeight: FontSizes.medium
                        }
                    }
                },
                "$value": {
                    margin: 20
                }
            }
        },
        additional: {
            
        },
        value: {
            border: `1px solid ${theme.palette.neutralLight}`,
            borderRadius: 4,
            marginLeft: 4,
            marginRight: 4
        }
    };
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles : ISearchResultStyles) : ISearchResultStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export { ISearchResultStyles, getStyles, Defaults, defaultStyles }