import * as React from "react";
import { isNotBlank } from "../../StringUtils";
import { DefinitionList } from "../../component/DefinitionList";
import { SearchGroupOperator } from "../SearchGroupOperator";
import { ISearchField } from "../ISearchField";
import { ISearchRequest } from "../ISearchRequest";
import { getStyles, ISearchRequestSummaryStyles } from "./SearchRequestSummary.styles";
import { getClassNames } from "./SearchRequestSummary.classNames";
import { ISearchGroup } from "../ISearchGroup";
import { ISearchSchema } from "../ISearchSchema";
import { getSchemaField } from "../SearchHelper";

interface ISearchRequestSummaryProps {
    request: ISearchRequest;
    schema?: ISearchSchema;
    styles?: ISearchRequestSummaryStyles;
    className?: string;
    hideOperator?: boolean;
}

interface ISearchFieldSummaryProps {
    field: ISearchField;
    schema?: ISearchSchema;
    styles?: ISearchRequestSummaryStyles;
    className?: string;
}

class SearchFieldSummary extends React.Component<ISearchFieldSummaryProps, any> {
    render() {
        const { field, styles, className } = this.props;
        const classNames = getClassNames(getStyles(null, styles), className);
        const schemaField = getSchemaField(this.props.schema, field.name);
        return <DefinitionList className={classNames.value} name={schemaField ? schemaField.name : field.name}>{field.searchString}</DefinitionList>;
    }
}

interface ISearchGroupSummaryProps {
    group: ISearchGroup;
    child?: boolean;
    schema?: ISearchSchema;
    styles?: ISearchRequestSummaryStyles;
    className?: string;
}

class SearchGroupSummary extends React.Component<ISearchGroupSummaryProps, any> {
    render() {
        const { group, schema, styles, className } = this.props;
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.group}>
                <div className={classNames.op}>
                    {group.op || SearchGroupOperator.AND}
                </div>
                {group.fields ? group.fields.map((field, index) => {
                    return <SearchFieldSummary key={`field${index}`} field={field} schema={schema} styles={styles} className={className} />;
                }) : undefined}
                {group.groups ? group.groups.map((cg, index) => {
                    return <SearchGroupSummary key={`group${index}`} group={cg} schema={schema} styles={styles} className={className} />;
                }) : undefined}
            </div>
        );
    }
}

class SearchRequestSummary extends React.Component<ISearchRequestSummaryProps, any> {
    render() {
        const { request, schema, styles, className } = this.props;
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.root}>
                <div className={classNames.op}>
                    {request.op || SearchGroupOperator.AND}
                </div>
                {isNotBlank(request.searchString) &&
                    <div className={classNames.value}>{request.searchString}</div>
                }
                {request.fields ? request.fields.map((field, index) => {
                    return <SearchFieldSummary key={`field${index}`} field={field} schema={schema} styles={styles} className={className} />;
                }) : undefined}
                {request.groups ? request.groups.map((cg, index) => {
                    return <SearchGroupSummary key={`group${index}`} group={cg} schema={schema} styles={styles} className={className} />;
                }) : undefined}
            </div>
        );
    }
}

export { ISearchRequestSummaryProps, SearchRequestSummary }