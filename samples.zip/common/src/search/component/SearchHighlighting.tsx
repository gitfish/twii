import * as React from "react";
import { ISearchResponseFieldHighlighting } from "../ISearchResponse";
import {
    splitHighlight,
    isElementHighlighted,
    findHighlight
} from "../SearchHighlightUtils";

interface ISearchHighlightingProps {
    value: string,
    onRenderHighlightElement?: (value : string, index : number) => React.ReactNode;
    openDelim?: string;
    closeDelim?: string;
}

class SearchHighlighting extends React.Component<ISearchHighlightingProps, any> {
    protected _onRenderHighlightElement = (el : string, index : number) : React.ReactNode => {
        if(this.props.onRenderHighlightElement) {
            return this.props.onRenderHighlightElement(el, index);
        }
        return <strong key={index}>{el}</strong>;
    }
    render() {
        const { value } = this.props;
        const r = [];
        const els = splitHighlight(value, this.props.openDelim, this.props.closeDelim);
        els.forEach((el, idx) => {
            if(isElementHighlighted(value, el, this.props.openDelim, this.props.closeDelim)) {
                r.push(this._onRenderHighlightElement(el, idx));
            } else {
                r.push(el);
            }
        });
        return r;
    }
}

interface ISearchFieldHighlightingProps extends ISearchHighlightingProps {
    highlighting: ISearchResponseFieldHighlighting;
    field: string;
}

class SearchFieldHighlighting extends React.Component<ISearchFieldHighlightingProps, any> {
    render() {
        const { highlighting, field, value } = this.props;
        const fieldHighlights = highlighting[field];
        const highlight = findHighlight(value, fieldHighlights, this.props.openDelim, this.props.closeDelim);
        if(highlight) {
            return <SearchHighlighting {...this.props} value={highlight} />;
        }
        return value;
    }
}

export {
    ISearchHighlightingProps,
    SearchHighlighting,
    ISearchFieldHighlightingProps,
    SearchFieldHighlighting
}
