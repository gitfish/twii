import * as React from "react";
import { ISearchListModel } from "../model/ISearchListModel";
import { SearchHighlighting } from "./SearchHighlighting";
import { getStyles, ISearchResultStyles } from "./SearchResult.styles";
import { getClassNames } from "./SearchResult.classNames";
import { SearchableValue } from "./SearchableValue";
import { ISearchField } from "../ISearchField";
import { getResultHighlighting, getHighlightedResultValues } from "../SearchHighlightUtils";
import { Callout } from "office-ui-fabric-react/lib/Callout";
import { css } from "@uifabric/utilities";
import { ISearchResultValue } from "../ISearchResultValue";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import { SearchResultValueList } from "./SearchResultValueList";

interface ISearchResultProps {
    list: ISearchListModel<any>;
    fields: string[];
    result: any;
    index: number;
    onRenderCell?: (value : ISearchResultValue, index?: number, isScrolling?: boolean) => React.ReactNode;
    onClickValue?: (props : ISearchField) => void;
    styles?: ISearchResultStyles;
    className?: string;
    title?: string;
    valueLimit?: number;
    flex?: boolean;
}

interface ISearchResultValueProps extends ISearchResultProps, ISearchResultValue {}

class SearchResultValue extends React.Component<ISearchResultValueProps, any> {
    private _onRenderCell = () => {
        if(this.props.onRenderCell) {
            return this.props.onRenderCell(this.props, this.props.index, false);
        }
        return this.props.highlight ? <SearchHighlighting value={this.props.highlight} /> : this.props.value;
    }
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <SearchableValue className={classNames.value}
                             name={this.props.field}
                             title={this.props.title}
                             searchString={this.props.value}
                             onClick={this.props.onClickValue}>
                {this._onRenderCell()}
            </SearchableValue>
        );
    }
}

class AllSearchResultValues extends React.Component<ISearchResultProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.additional}>
                <SearchResultValueList {...this.props} />
            </div>
        );
       
    }
}

interface IAllSearchResultValuesTriggerState {
    on?: boolean;
}

class AllSearchResultValuesTrigger extends React.Component<ISearchResultProps, IAllSearchResultValuesTriggerState> {
    private _calloutTarget : HTMLElement;
    constructor(props) {
        super(props);
        this.state = { on: false };
    }
    private _onClick = (e : React.MouseEvent<HTMLButtonElement>) => {
        this._calloutTarget = e.target as HTMLElement;
        this.setState({ on: !this.state.on });
    }
    private _onCalloutDismiss = () => {
        this.setState({ on: false });
    }
    render() {
        return (
            <div>
                <IconButton iconProps={{ iconName: "more"}} onClick={this._onClick} title="Show All Values" />
                {this.state.on && (
                    <Callout target={this._calloutTarget} onDismiss={this._onCalloutDismiss} calloutWidth={400} calloutMaxHeight={300}>
                        <AllSearchResultValues {...this.props} />
                    </Callout>
                )}
            </div>
        );
    }
}

class SearchResultValues extends React.Component<ISearchResultProps, any> {
    render() {
        const { list, result, valueLimit, fields } = this.props;
        let values : ISearchResultValue[] = getHighlightedResultValues(result, fields, getResultHighlighting(list.highlighting, result));
        let additionalValues : boolean = false;
        if(valueLimit > 0 && values.length > valueLimit) {
            additionalValues = true;
            values = values.slice(0, valueLimit);
        }
        if(values.length > 0) {
            const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
            return (
                <div className={css(classNames.root, { flex: this.props.flex })}>
                    {values.map((value, idx) => {
                        return <SearchResultValue key={idx} {...this.props} {...value} />;
                    })}
                    {additionalValues && <AllSearchResultValuesTrigger {...this.props} />}
                </div>
            );
        }
        return null;
    }
}

export {
    ISearchResultValue,
    ISearchResultValueProps,
    ISearchResultProps,
    SearchResultValue,
    SearchResultValues
}