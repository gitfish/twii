const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const GeneratorPlugin = require("./webpack.plugins").GeneratorPlugin;
const WriteFilePlugin = require("write-file-webpack-plugin");

const contains = (...values) => {
    return (filename) => {
        return values.some(value => {
            return filename.indexOf(value) >= 0;
        });
    }
};

const isNodeModuleFile = contains("node_modules");

const some = (...p) => {
    return (filename => {
        return p.some(e => e(filename));
    });
};

const endsWith = (...extensions) => {
    return (filename) => {
        return extensions.some(ext => {
            return filename.endsWith(ext);
        });
    };
};

const createConfig = (env) => {
    if(!env) {
        env = {};
    }
    // NOTE: this is the legacy path - will have to do some work to update it
    const publicPath = env && env.publicPath ? env.publicPath : "/analystdesktop/widget/site/";
    const defaultConfig = {
        basePath: publicPath,
        publicPath: publicPath,
        fabricFontBasePath: "/analystdesktop/widget/site", // Fabric appends /fonts/... 
        fabricIconBasePath: "/analystdesktop/widget/site/icons/fabric/",
        buildVersion: env.production ? "production" : "development",
        buildDate: new Date().toISOString()
    };
    const AppConfig = Object.assign({}, defaultConfig, env);

    const config = {
        mode: AppConfig.production ? "production" : "development",
        entry: {
            main: ["./src/main.tsx"]
        },
        output: {
            filename: AppConfig.production ? "[name].[chunkhash].js" : "[name].js",
            path: path.join(__dirname, "dist"),
            publicPath: publicPath
        },
        externals: [
            {'./node_modules/jszip': 'jszip'}
        ],
        module: {
            rules: [
                {
                    enforce: "pre",
                    test: endsWith(".ts", ".tsx"),
                    loader: "source-map-loader",
                    exclude: some(isNodeModuleFile, endsWith(".template.ts"))
                },
                {
                    test: endsWith(".ts", ".tsx"),
                    loader: "ts-loader",
                    exclude: isNodeModuleFile
                },
                {
                    test: endsWith(".css"),
                    use: [
                        { loader: "@microsoft/loader-load-themed-styles" },
                        { loader: "css-loader" }
                    ]
                },
                {
                    test: endsWith(".scss"),
                    use: [
                        { loader: "@microsoft/loader-load-themed-styles" },
                        { loader: "css-loader" },
                        { 
                            loader: "sass-loader",
                            options: {
                                data: `$ms-font-cdn-path: "${AppConfig.fabricFontBasePath}";`
                            }
                        }
                    ]
                },
                {
                    test: endsWith(".woff", ".woff2", ".font.svg", ".ttf", ".eot"),
                    use: [
                        { loader: "file-loader" }
                    ]
                },
                {
                    test: endsWith(".png", ".jpg", ".gif"),
                    use: [
                        { loader: "file-loader" }
                    ]
                }
            ]
        },
        resolve: {
            extensions: [".js", ".tsx", ".ts"],
            modules: [
                path.resolve(__dirname, "src"), "node_modules"
            ],
            alias: {
                "package.json$": path.resolve(__dirname, "package.json")
            }
        },
        devtool: "source-map",
        devServer: {
            contentBase: "./dist",
            historyApiFallback: true
        },
        plugins: [
            new HtmlWebpackPlugin({
                title: "Analyst Desktop",
                template: "src/index.template.ts",
                AppConfig: AppConfig,
                chunks: ["main"],
                chunksSortMode: "none"
            }),
            new CopyWebpackPlugin([
                { from: 'report_templates', to: 'report_templates' },
                { from: "fonts", to: "fonts" },
                { from: `${path.dirname(require.resolve('@uifabric/icons'))}/../fonts`, to: "icons/fabric" }
            ]),
            new GeneratorPlugin({
                generator: () => {
                    return `window.AppConfig = ${JSON.stringify(AppConfig, null, "\t")};`
                },
                filename: "AppConfig.js"
            }),
            new WriteFilePlugin()
        ]
    };

    return config;
};

module.exports = createConfig;