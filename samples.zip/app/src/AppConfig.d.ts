// NOTE: this is the global app config type definition
declare var AppConfig : any;