declare module "file-loader?!*"
declare module "url-loader?!*"
declare module "*.json"
declare module "*.png"