import { mergeStyleSets } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";
import { IAboutStyles } from "./About.styles";

interface IAboutClassNames {
    root?: string;
    section?: string;
    sectionTitle?: string;
    sectionBody?: string;
    config?: string;
}

const getClassNames = memoizeFunction((styles : IAboutStyles, className?: string) : IAboutClassNames => {
    return mergeStyleSets({
        root: ["about", className, styles.root],
        section: ["about-section", styles.section],
        sectionTitle: ["about-section-title", styles.sectionTitle],
        sectionBody: ["about-section-body", styles.sectionBody],
        config: ["about-config", styles.config]
    });
});

export { IAboutClassNames, getClassNames }