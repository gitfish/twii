import * as React from "react";
import { observer } from "mobx-react";
import { Link } from "office-ui-fabric-react/lib/components/Link";
import { DetailsList, IColumn, SelectionMode } from "office-ui-fabric-react/lib/components/DetailsList";
import { Panel, PanelType } from "office-ui-fabric-react/lib/Panel";
import { IMutableSupplier } from "@twii/common/lib/IMutableSupplier";
import { IAboutStyles, getStyles } from "./About.styles";
import { getClassNames } from "./About.classNames";
import packageInfo from "package.json";
import { IAppProps } from "@twii/common/lib/component/IAppProps";

const dependencies =  Object.keys(packageInfo.dependencies || {}).map(key => {
    return {
        name: key,
        version: packageInfo.dependencies[key]
    };
}).sort((l, r) => {
    return String(l.name).localeCompare(String(r.name));
});

const dependencyColumns : IColumn[] = [
    {
        key: "name",
        name: "Name",
        fieldName: "name",
        minWidth: 40,
        maxWidth: 200,
        isResizable: true
    },
    {
        key: "version",
        name: "Version",
        fieldName: "version",
        minWidth: 40,
        isResizable: true
    }
]

class DependenciesDetailsList extends React.Component<any, any> {
    private _onShouldVirtualize = () => {
        return false;
    }
    render() {
        return (
            <DetailsList items={dependencies} columns={dependencyColumns} selectionMode={SelectionMode.none} onShouldVirtualize={this._onShouldVirtualize} />
        );
    }
}

interface IAboutProps {
    styles?: IAboutStyles;
    className?: string;
}

class About extends React.Component<IAboutProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.root}>
                <section className={classNames.section}>
                    <h5 className={classNames.sectionTitle}>Build Version</h5>
                    <div className={classNames.sectionBody}>
                        {AppConfig.buildVersion}
                    </div>
                </section>
                <section className={classNames.section}>
                    <h5 className={classNames.sectionTitle}>Build Date</h5>
                    <div className={classNames.sectionBody}>
                        {AppConfig.buildDate}
                    </div>
                </section>
                <section className={classNames.section}>
                    <h5 className={classNames.sectionTitle}>Repository</h5>
                    <div className={classNames.sectionBody}>
                        <Link target="_blank" href={packageInfo.repository.url}>{packageInfo.repository.url}</Link>
                    </div>
                </section>
                <section className={classNames.section}>
                    <h5 className={classNames.sectionTitle}>Configuration</h5>
                    <div className={classNames.sectionBody}>
                        <pre className={classNames.config}>{JSON.stringify(AppConfig, null, "\t")}</pre>
                    </div>
                </section>
                <section className={classNames.section}>
                    <h5 className={classNames.sectionTitle}>Dependencies</h5>
                    <div className={classNames.sectionBody}>
                        <DependenciesDetailsList />
                    </div>
                </section>
            </div>
        );
    }
}

class AboutApp extends React.Component<IAppProps, any> {
    componentWillMount() {
        this.props.match.host.setTitle("About appsmart");
    }
    render() {
        return <About />;
    }
}

export { AboutApp, AboutApp as default, About }