import { IStyle, getTheme } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities/lib";
import { ITheme, concatStyleSets, FontSizes } from "@uifabric/styling/lib";

interface IBrandStyles {
    root?: IStyle;
    logo?: IStyle;
    title?: IStyle;
}

const getStyles = memoizeFunction((theme : ITheme, customStyles?: IBrandStyles) : IBrandStyles => {
    if(!theme) {
        theme = getTheme();
    }
    const defaultStyles : IBrandStyles = {
        root: {
        },
        logo: {
            zIndex: 1,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            position: "absolute",
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        },
        title: {
            color: theme.palette.neutralLight,
            zIndex: 2,
            fontSize: FontSizes.medium
        }
    };

    return concatStyleSets(defaultStyles, customStyles);
});

export { IBrandStyles, getStyles }