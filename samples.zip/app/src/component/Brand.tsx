import * as React from "react";
import { CommandBarButton } from "office-ui-fabric-react/lib/Button";
import { Image } from "office-ui-fabric-react/lib/Image";
import { IBrandStyles, getStyles } from "./Brand.styles";
import { IBrandClassNames, getClassNames } from "./Brand.classNames";
import logoUrl from "./Logo.png";

interface IBrandButtonProps {
    onClick?: () => void;
    styles?: IBrandStyles;
    className?: string;
}

class BrandButton extends React.Component<IBrandButtonProps, any> {
    private _classNames : IBrandClassNames;
    private _renderLogo() : React.ReactNode {
        return (
            <div className={this._classNames.logo} aria-hidden={true}>
                <Image src={String(logoUrl)} alt="appsmart" />
            </div>
        );
    }
    private _renderTitle() : React.ReactNode {
        return (
            <div className={this._classNames.title}>
                appsmart
            </div>
        )
    }
    render() {
        this._classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <CommandBarButton onClick={this.props.onClick}>
                {this._renderLogo()}
                {this._renderTitle()}
            </CommandBarButton>
        )
    }
}

export { BrandButton, IBrandButtonProps }