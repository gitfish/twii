import "core-js";
import * as React from "react";
import * as ReactDOM from "react-dom";
import { BrowserAppHost } from "@twii/common/lib/model/BrowserAppHost";
import { AppHostContainer } from "@twii/common/lib/component/AppHost";
import { AppRouter } from "./AppRouter";
import { Fabric } from "office-ui-fabric-react/lib/Fabric";
import { initializeIcons } from "@uifabric/icons";
import { ConfigContext } from "@twii/common/lib/ConfigContext";
import { RouterContext } from "@twii/common/lib/RouterContext";
import { HostContext } from "@twii/common/lib/HostContext";
import { attachWindowMessaging } from "@twii/common/lib/WindowMessaging";
import "./main.scss";

attachWindowMessaging(window);

const host = new BrowserAppHost();
host.setRoot(true);
host.window = window;
host.router = AppRouter;
host.publicPath = AppConfig.publicPath;

// app context config
ConfigContext.value = AppConfig;
RouterContext.value = AppRouter;
HostContext.value = host;

// fabric icon initialization
initializeIcons(AppConfig.fabricIconBasePath);

const el = document.createElement("div");
document.body.appendChild(el);

// render
ReactDOM.render(
    <Fabric className="analyst-desktop">
        <AppHostContainer host={host} />
    </Fabric>,
    el
);