import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import axios from "axios";
import { HostAppView } from "@twii/common/lib/component/HostAppView";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";

class AxiosTestApp extends React.Component<IAppProps, any> {
    get host() : IAppHost {
        return this.props.match.host;
    }
    private _onTest = () => {
        axios.post("http://phd2e1:8187?gremlin", {
            gremlin: "g.V().has('node', 'cdh:168799928').valueMap()"
        }, {
            auth: {
                username: "excbnl",
                password: "strikeit"
            }
        }).then(r => {
            console.log(JSON.stringify(r.data));
        }).catch(err => {
            console.error(err);  
        });
    }
    render() {
        return (
            <HostAppView host={this.host}>
                <PrimaryButton onClick={this._onTest}>Test</PrimaryButton>
            </HostAppView>
        )
    }
}

export { AxiosTestApp as default, AxiosTestApp }