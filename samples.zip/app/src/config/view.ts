import "./styles/AppView.styles";
import { ListingViewConfig } from "@twii/ozone/lib/listing/component/ListingViewConfig";

ListingViewConfig.label = "App";
ListingViewConfig.labelPlural = "Apps";
ListingViewConfig.storeLabel = "App Store";