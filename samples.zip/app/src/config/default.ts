import { LoggingStorageService } from "@twii/common/lib/service/LoggingStorageService";
import { ChainedStorageService } from "@twii/common/lib/service/ChainedStorageService";
import { TransientStorageService } from "@twii/common/lib/service/TransientStorageService";
import { ListingServiceContext } from "@twii/ozone/lib/listing/service/ListingServiceContext";
import { RestListingService } from "@twii/ozone/lib/listing/service/RestListingService";
import { ImageServiceContext } from "@twii/ozone/lib/media/service/ImageServiceContext";
import { RestImageService } from "@twii/ozone/lib/media/service/RestImageService";
import { CategoryServiceContext } from "@twii/ozone/lib/category/service/CategoryServiceContext";
import { RestCategoryService } from "@twii/ozone/lib/category/service/RestCategoryService";
import { UserServiceContext } from "@twii/ozone/lib/user/service/UserServiceContext";
import { RestUserService } from "@twii/ozone/lib/user/service/RestUserService";
import { UserDataServiceContext } from "@twii/ozone/lib/user/service/UserDataServiceContext";
import { UserDataStorageService } from "@twii/ozone/lib/user/service/UserDataStorageService";
import { RestUserDataService } from "@twii/ozone/lib/user/service/RestUserDataService";
import { UserAdminContext } from "@twii/ozone/lib/user/UserAdminContext";
import { isMemberOfGroup } from "@twii/ozone/lib/user/UserHelper";
import { DashboardStorageServiceContext } from "../service/DashboardStorageServiceContext";
import { BrowserStorageService } from "@twii/common/lib/service/BrowserStorageService";
import { StorageServiceContext } from "@twii/common/lib/StorageServiceContext";
import { DashboardStorageServiceContext as EntityDashboardStorageContext } from "@twii/entity/lib/common/DashboardStorageServiceContext";
import { Defaults } from "@twii/entity/lib/common/service/AbstractRestDataService";
import UserGroup from "user/UserGroup";
import get from "get-value";

const configure = (env : any) => {
    console.log("-- Applying Default Configuration");

    // ozone config

    // admin context
    UserAdminContext.value = userProfile => {
        return isMemberOfGroup(userProfile, UserGroup.ADMIN);
    };

    const apiBaseUrl = get(env, "ozone.api.baseUrl") || "/analystdesktop/api";
    console.log("-- Ozone Api Base Url: " + apiBaseUrl);

    // NOTE that this is for local usage
    let apiAuth;
    const apiUsername = get(env, "ozone.api.username");
    const apiPassword = get(env, "ozone.api.password");
    if(apiUsername && apiPassword) {
        apiAuth = {
            username: apiUsername,
            password: apiPassword
        };
    }
    const iwcApiBaseUrl = get(env, "ozone.iwc-api.baseUrl") || "/analystdesktop/iwc-api";
    console.log("-- Ozone Iwc Api Base Url: " + iwcApiBaseUrl);

    const userService = new RestUserService();
    userService.baseUrl = apiBaseUrl;
    userService.auth = apiAuth;
    UserServiceContext.value = userService;

    const userDataService = new RestUserDataService();
    userDataService.baseUrl = iwcApiBaseUrl;
    userDataService.auth = apiAuth;
    UserDataServiceContext.value = userDataService;

    const listingService = new RestListingService();
    listingService.baseUrl = apiBaseUrl;
    listingService.auth = apiAuth;
    ListingServiceContext.value = listingService;

    const imageService = new RestImageService();
    imageService.baseUrl = apiBaseUrl;
    imageService.auth = apiAuth;
    ImageServiceContext.value = imageService;

    const categoryService = new RestCategoryService();
    categoryService.baseUrl = apiBaseUrl;
    categoryService.auth = apiAuth;
    CategoryServiceContext.value = categoryService;

    // global config
    const storageService = new ChainedStorageService([
        new LoggingStorageService({
            target: new BrowserStorageService(localStorage),
            prefix: "localStorage"
        }),
        new LoggingStorageService({
            target: new UserDataStorageService(),
            prefix: "iwcUserDataStorage"
        })
    ]);
    StorageServiceContext.value = storageService;

    // dashboard config
    const dashboardStorageService = new ChainedStorageService([
        new LoggingStorageService({
            target: new TransientStorageService(),
            prefix: "transientStorage"
        }),
        new LoggingStorageService({
            target: new UserDataStorageService(),
            prefix: "iwcUserDataStorage"
        })
    ]);
    DashboardStorageServiceContext.value = dashboardStorageService;
    EntityDashboardStorageContext.value = dashboardStorageService;

    const dsApiBaseUrl = get(env,"ds.api.baseUrl") || "/DataServices";
    console.log("-- Data Services Api Base Url: " + dsApiBaseUrl);
    Defaults.baseUrl = dsApiBaseUrl;
};

export { configure, configure as default };