    import MasterEntitySearchServiceContext from "@twii/entity/lib/entity/MasterEntitySearchServiceContext";
import MockMasterEntitySearchService from "@twii/entity/lib/entity/MockMasterEntitySearchService";
import MasterEntityDataServiceContext from "@twii/entity/lib/entity/MasterEntityDataServiceContext";
import MockMasterEntityDataService from "@twii/entity/lib/entity/MockMasterEntityDataService";
import IATServiceContext from "@twii/entity/lib/iat/IATServiceContext";
import MockIATService from "@twii/entity/lib/iat/MockIATService";
import BAGSServiceContext from "@twii/entity/lib/bags/BAGSServiceContext";
import MockBAGSService from "@twii/entity/lib/bags/MockBAGSService";
import EXAMSServiceContext from "@twii/entity/lib/exams/EXAMSServiceContext";
import MockEXAMSService from "@twii/entity/lib/exams/MockEXAMSService";
import DGMSServiceContext from "@twii/entity/lib/dgms/DGMSServiceContext";
import MockDGMSService from "@twii/entity/lib/dgms/MockDGMSService";
import AirCargoServiceContext from "@twii/entity/lib/cargo/air/AirCargoServiceContext";
import MockAirCargoService from "@twii/entity/lib/cargo/air/MockAirCargoService";
import SeaCargoServiceContext from "@twii/entity/lib/cargo/sea/SeaCargoServiceContext";
import MockSeaCargoService from "@twii/entity/lib/cargo/sea/MockSeaCargoService";
import MockIATAService from "@twii/entity/lib/iata/MockIATAService";
import IATAServiceContext from "@twii/entity/lib/iata/IATAServiceContext";
import MockINTCPService from "@twii/entity/lib/intcp/MockINTCPService";
import INTCPServiceContext from "@twii/entity/lib/intcp/INTCPServiceContext";
import { EntityPhotosServiceContext } from "@twii/entity/lib/entityphotos/service/EntityPhotosServiceContext";
import { MockEntityPhotosService } from "@twii/entity/lib/entityphotos/service/MockEntityPhotosService";
import { LoggingStorageService } from "@twii/common/lib/service/LoggingStorageService";
import { TransientStorageService } from "@twii/common/lib/service/TransientStorageService";
import { ListingServiceContext } from "@twii/ozone/lib/listing/service/ListingServiceContext";
import { MockListingService, nextListingId, nextListingBookmarkid } from "@twii/ozone/lib/listing/service/MockListingService";
import { CategoryServiceContext } from "@twii/ozone/lib/category/service/CategoryServiceContext";
import { MockCategoryService } from "@twii/ozone/lib/category/service/MockCategoryService";
import { ImageServiceContext } from "@twii/ozone/lib/media/service/ImageServiceContext";
import { MockImageService } from "@twii/ozone/lib/media/service/MockImageService";
import { UserServiceContext } from "@twii/ozone/lib/user/service/UserServiceContext";
import { MockUserService } from "@twii/ozone/lib/user/service/MockUserService";
import { UserDataServiceContext } from "@twii/ozone/lib/user/service/UserDataServiceContext";
import { MockUserDataService } from "@twii/ozone/lib/user/service/MockUserDataService";
import { DashboardStorageServiceContext } from "../service/DashboardStorageServiceContext";
import { ListingApprovalStatus } from "@twii/ozone/lib/listing/ListingApprovalStatus";
import { IListing } from "@twii/ozone/lib/listing/IListing";
import { UserAdminContext } from "@twii/ozone/lib/user/UserAdminContext";
import { isMemberOfGroup } from "@twii/ozone/lib/user/UserHelper";
import { StorageServiceContext } from "@twii/common/lib/StorageServiceContext";
import { DashboardStorageServiceContext as EntityDashboardStorageServiceContext } from "@twii/entity/lib/common/DashboardStorageServiceContext";
import UserGroup from "../user/UserGroup";

import {MockVisaHistoryCaseSummaryService} from "@twii/matcheval/lib/me/visahistory/MockVisaHistoryCaseSummaryService";
import {VisaHistoryServiceContext} from "@twii/matcheval/lib/me/visahistory/VisaHistoryServiceContext";
import { ABRServiceContext } from "@twii/entity/lib/abr/service/ABRServiceContext";
import { MockABRService } from "@twii/entity/lib/abr/service/MockABRService";
import { EntitySearchServiceContext } from "@twii/entity/lib/search/service/EntitySearchServiceContext";
import { MockEntitySearchService } from "@twii/entity/lib/search/service/MockEntitySearchService";
import entitySearchImage from "./entitysearch.png";

const configure = (env : any) => {
    console.log("-- Applying Mock Configuration");
    const storageService = new LoggingStorageService({
        prefix: "mock",
        target: new TransientStorageService()
    });

    // common config
    StorageServiceContext.value = storageService;

    // bored config 
    DashboardStorageServiceContext.value = storageService;
    
    // ozone config
    // admin context
    UserAdminContext.value = userProfile => {
        return isMemberOfGroup(userProfile, UserGroup.ADMIN);
    };

    const userService = new MockUserService();
    userService.userProfile = {
        id: 1,
        display_name: "Mock User",
        bio: "Mock User Bio",
        user: {
            username: "mock",
            email: "mock@ande.dev",
            groups: [
                {
                    name: "USER"
                },
                {
                    name: "APPS_MALL_STEWARD"
                },
                {
                    name: "analyst_desktop_entity_search"
                },
                {
                    name: "analyst_desktop_match_evaluation"
                },
                {
                    name: "analyst_desktop_risk_resume"
                }
            ]
        }
    }
    UserServiceContext.value = userService;
    UserDataServiceContext.value = new MockUserDataService();
    const listingService = new MockListingService();
    const listings : IListing[] = [
        {
            id: nextListingId(),
            unique_name: "entity.search.new",
            title: "Entity Search (NEW)",
            description: "Entity Search (NEW)",
            description_short: "Entity Search (NEW)",
            launch_url: "/entity/search/new",
            security_marking: "analyst_desktop_entity_search",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: true,
            small_icon: {
                url: entitySearchImage
            },
            large_icon: {
                url: entitySearchImage
            },
            banner_icon: {
                url: entitySearchImage
            }
        },
        {
            id: nextListingId(),
            unique_name: "entity.search",
            title: "Entity Search",
            description: "Entity Search",
            description_short: "Entity Search",
            launch_url: "/entity/search",
            security_marking: "analyst_desktop_entity_search",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: true
        },
        {
            id: nextListingId(),
            unique_name: "entity.profile",
            title: "Clipboard",
            description: "Clipboard",
            description_short: "Clipboard",
            launch_url: "/entity/profile",
            security_marking: "analyst_desktop_entity_search",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "vra.search",
            title: "Risk Resume",
            description: "Risk Resume",
            description_short: "Risk Resume",
            launch_url: "/vra/search",
            security_marking: "analyst_desktop_risk_resume",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "me.casemanagement",
            title: "ME Case Management",
            description: "ME Case Management",
            description_short: "ME Case Management",
            launch_url: "/me/portal",
            security_marking: "analyst_desktop_match_evaluation",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true
        },
        {
            id: nextListingId(),
            unique_name: "itm.portal",
            title: "ITM Portal",
            description: "ITM Portal",
            description_short: "ITM Portal",
            launch_url: "https://e6-portals.immi.gov.au/protectedportal",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: false
        },
        {
            id: nextListingId(),
            unique_name: "itm.reporting",
            title: "ITM Reporting",
            description: "ITM Reporting",
            description_short: "ITM Reporting",
            launch_url: "http://birs-st/BOE/BI",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: false
        },
        {
            id: nextListingId(),
            unique_name: "google",
            title: "Google",
            description: "Google",
            description_short: "Google",
            launch_url: "http://www.google.com",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: false
        },
        {
            id: nextListingId(),
            unique_name: "Microsoft",
            title: "Microsoft",
            description: "Microsoft",
            description_short: "Microsoft",
            launch_url: "http://www.microsoft.com",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: false,
            iframe_compatible: false
        },
        {
            id: nextListingId(),
            unique_name: "mesh.producer",
            title: "Mesh Producer",
            description: "Mesh Producer",
            description_short: "Mesh Producer",
            launch_url: "http://localhost:8080/analystdesktop/widget/site/mesh/sample/producer",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: true
        },
        {
            id: nextListingId(),
            unique_name: "mesh.consumer",
            title: "Mesh Consumer",
            description: "Mesh Consumer",
            description_short: "Mesh Consumer",
            launch_url: "http://localhost:8080/analystdesktop/widget/site/mesh/sample/consumer",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: true
        },
        {
            id: nextListingId(),
            unique_name: "mesh.embedded",
            title: "Mesh Embedded",
            description: "Mesh Embedded",
            description_short: "Mesh Embedded",
            launch_url: "/mesh/sample/embedded",
            security_marking: "USER",
            approval_status: ListingApprovalStatus.APPROVED,
            is_enabled: true,
            iframe_compatible: true
        }
    ];
    const bookmarks = listings.map(l => {
        return {
            id: nextListingBookmarkid(),
            listing: l
        };
    });
    listingService.listings = listings;
    listingService.bookmarks = bookmarks;
    ListingServiceContext.value = listingService;
    ImageServiceContext.value = new MockImageService();
    CategoryServiceContext.value = new MockCategoryService();
    
    // entity config
    EntityPhotosServiceContext.value = new MockEntityPhotosService();
    EntityDashboardStorageServiceContext.value = storageService;
    MasterEntitySearchServiceContext.value = new MockMasterEntitySearchService();
    MasterEntityDataServiceContext.value = new MockMasterEntityDataService();
    IATServiceContext.value = new MockIATService();
    BAGSServiceContext.value = new MockBAGSService();
    EXAMSServiceContext.value = new MockEXAMSService();
    DGMSServiceContext.value = new MockDGMSService();
    AirCargoServiceContext.value = new MockAirCargoService();
    SeaCargoServiceContext.value = new MockSeaCargoService();
    IATAServiceContext.value = new MockIATAService();
    INTCPServiceContext.value = new MockINTCPService();
    ABRServiceContext.value = new MockABRService();
    EntitySearchServiceContext.value = new MockEntitySearchService();

    // ME Visa History
    VisaHistoryServiceContext.value = new MockVisaHistoryCaseSummaryService();
};

export { configure, configure as default };