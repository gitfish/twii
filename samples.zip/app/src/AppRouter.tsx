import { Router } from "@twii/common/lib/Router";
import EntityRouter from "@twii/entity/lib/EntityRouter";
import MERouter from "@twii/matcheval/lib/me/MERouter";
//import RiskRouter from "@twii/matcheval/lib/risk/RiskRouter";
import RiskResumeRouter from "@twii/riskresume/lib/RiskResumeRouter";
//import PNRRouter from "@twii/kitchensink/lib/pnr/PNRRouter";
import CIERouter from "@twii/kitchensink/lib/cie/CIERouter";
import DirectSearchRouter from "@twii/kitchensink/lib/directsearch/DirectSearchRouter";
import MESearchRouter from "@twii/mesearch/lib/MESearchRouter";
//import SearchRouter from "@twii/kitchensink/lib/search/SearchRouter";
import { requiresGroupRouter, injectUserProfile } from "@twii/ozone/lib/user/UserAuthRouters";
import { Router as OzoneRouter } from "@twii/ozone/lib/Router";
import { UserGroup } from "./user/UserGroup";
import { ConfigRouter } from "@twii/common/lib/ConfigRouter";
import { reactRouter } from "@twii/common/lib/Routers";
import * as configMap from "./config/map";
import { PathsContext as OzonePathsContext } from "@twii/ozone/lib/PathsContext";
import { Paths as OzonePaths } from "@twii/ozone/lib/Paths";
import { PathsContext as EntityPathsContext } from "@twii/entity/lib/PathsContext";
import { Paths as EntityPaths } from "@twii/entity/lib/Paths";

const r = new Router();

// these are our 'interceptors'
// common config
r.use((req, next) => {
    return import("./config/common").then(() => {
        next();
    });
});

// config
r.use(new ConfigRouter({
    env: AppConfig,
    configMap: configMap
}));

// ozone config
r.use(injectUserProfile());

r.use("/about", reactRouter(() => import("./component/About")));
r.use("/help", reactRouter(() => import("./component/Help")));

OzonePathsContext.value = new OzonePaths("/appsmart");
r.use("/appsmart", OzoneRouter);

// r.use("/search", SearchRouter);
// set paths to match router prefix
EntityPathsContext.value = new EntityPaths("/entity");
r.use("/entity", requiresGroupRouter(UserGroup.ENTITY_SEARCH, EntityRouter));
r.use("/me", requiresGroupRouter(UserGroup.MATCH_EVALUATION, MERouter));
r.use("/vra", requiresGroupRouter(UserGroup.RISK_RESUME, RiskResumeRouter));
r.use("/vra", requiresGroupRouter(UserGroup.MATCH_EVALUATION, MESearchRouter));
// r.use("/risk", createAuthRouter(RiskRouter, UserGroup.PNR_SEARCH));

// r.use("/pnr", createAuthRouter(PNRRouter, UserGroup.PNR_SEARCH));
r.use("/cie", CIERouter);
r.use("/directsearch", DirectSearchRouter);
r.use("/mesh/sample/producer", reactRouter(() => import("./mesh/sample/producer")));
r.use("/mesh/sample/consumer", reactRouter(() => import("./mesh/sample/consumer")));
r.use("/mesh/sample/embedded", reactRouter(() => import("./mesh/sample/embedded")));
r.use("/mess/axiosTest", reactRouter(() => import("./mess/component/AxiosTestApp")));
r.use("/blank", req => {
    return null;
});

const dashboardRouter = reactRouter(() => import("./component/DashboardsApp"), { exact: false });

r.use((req, next) => {
    if (req.path === "/" || req.path === "/index" || req.path === "/dashboard") {
        return dashboardRouter(req, next);
    }
    return next(req);
});

export { r as default, r as AppRouter }