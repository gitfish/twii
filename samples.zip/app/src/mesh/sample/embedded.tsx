import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { ScriptFrame } from "@twii/common/lib/component/ScriptFrame";
import { IUserProfile } from "@twii/ozone/lib/user/IUserProfile";

class EmbeddedApp extends React.Component<IAppProps, any> {
    get host() : IAppHost {
        return this.props.match.host;
    }
    get userProfile() : IUserProfile {
        return this.props.match.userProfile;
    }
    render() {
        return <ScriptFrame host={this.host}
                            src="http://localhost:8081/analystdesktop/entity/app.js"
                            config={Object.assign({}, AppConfig, { userProfile: this.userProfile })} /> 
    }
}

export { EmbeddedApp, EmbeddedApp as default }