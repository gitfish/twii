import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { HostAppView } from "@twii/common/lib/component/HostAppView";
import { DefaultButton } from "office-ui-fabric-react/lib/Button";

class ProducerApp extends React.Component<IAppProps, any> {
    get host() {
        return this.props.match.host;
    }
    componentDidMount() {
        if(window.parent) {
            window.parent.postMessage({ type: "subscribe", path: this.props.match.path }, "*");
        }
    }
    componentWillUnmount() {
        if(window.parent) {
            window.parent.postMessage({ type: "unmount", path: this.props.match.path }, "*");
        }
    }
    private _onClick = () => {
        if(window.parent) {
            window.parent.postMessage({ type: "info", path: this.props.match.path, appConfig: AppConfig }, "*");
        }
    }
    render() {
        return (
            <HostAppView host={this.host}>
                <div style={{ display: "flex", justifyContent: "center", alignItems: "center", padding: 10 }}>
                    <DefaultButton onClick={this._onClick}>Post Message</DefaultButton>
                </div>
            </HostAppView>
        );
    }
}

export { ProducerApp, ProducerApp as default }