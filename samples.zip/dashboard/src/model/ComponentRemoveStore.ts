import { ComponentRemove } from "./ComponentRemove";

const ComponentRemoveStore = new ComponentRemove();

export { ComponentRemoveStore }