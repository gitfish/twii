interface IGridBounds {
    rowIndex?: number;
    rowSpan?: number;
    colIndex?: number;
    colSpan?: number;
}

export { IGridBounds }