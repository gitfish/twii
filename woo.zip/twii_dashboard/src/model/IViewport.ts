interface IViewport {
    x: number;
    y: number;
    width: number;
    height: number;
}

export { IViewport }