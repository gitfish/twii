import { IHistoryModel } from "./model/IHistoryModel";
export { IHistoryModel as default, IHistoryModel }