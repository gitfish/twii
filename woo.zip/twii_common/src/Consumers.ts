import { IConsumerFunc } from "./IConsumerFunc";

const useless : IConsumerFunc = () => {};

export { useless }