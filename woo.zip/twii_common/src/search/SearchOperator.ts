enum SearchOperator {
    matchesPhrase = "matchesPhrase",
    matchesAnyTerm = "matchesAnyTerm",
    matchesAllTerms = "matchesAllTerms",
    // these apply to non-string values - i.e. numbers, dates and so on
    equals = "equals", 
    between = "between"
}

export { SearchOperator }