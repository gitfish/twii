import IUrlConfig from "./IUrlConfig";

const RestIwcApiConfig : IUrlConfig = {
    baseUrl: "/analystdesktop/iwc-api"
};

export { RestIwcApiConfig as default, RestIwcApiConfig }