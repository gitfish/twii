import * as React from "react";
import {css} from "office-ui-fabric-react/lib/Utilities";
import {PrimaryButton, IButtonProps, DefaultButton} from "office-ui-fabric-react/lib/Button";
import {Label} from "office-ui-fabric-react/lib/Label";
import "./ButtonGroup.scss";

interface IButtonGroupProps extends React.HTMLProps<HTMLElement> {
    selectedKeys?: string[];
    onChanged?: (item: IButtonProps | IButtonProps[]) => any,
    items: IButtonProps[];
    label?: string;
    multiSelect?: boolean;
    transition?: boolean;
}

class ButtonGroup extends React.Component<IButtonGroupProps, any> {
    selectedItems: IButtonProps[] = [];
    private _classNamePrefix = "ande-button-group";
    private _ref;

    componentWillMount() {

        if (this.props.selectedKeys) {
            this.selectedItems = this.props.items.filter(i => this.props.selectedKeys.find(j => j === i.uniqueId));
            this._onSelectItems(this.selectedItems);
        }
    }

    componentWillReceiveProps(newProps: IButtonGroupProps, oldProps: IButtonGroupProps) {
        if (this._shouldUpdateSelectedItems(newProps.selectedKeys)) {
            this.selectedItems = this.props.items.filter(i => newProps.selectedKeys.find(j => j === i.uniqueId));
            this._onSelectItems(this.selectedItems);
        }
    }

    private _setRef = ref => {
        if (!this._ref && ref) {
            this._ref = ref;
            this.forceUpdate();
        }
    }

    private _getItemClassName = (id: string | number) => {
        return `${this._classNamePrefix}--${id.toString().replace(" ", "_")}`
    };

    private _getStyle = (id: string | number): React.CSSProperties => {
        if (this._ref) {
            const thisItemElement = this._ref.querySelector(`.${this._getItemClassName(id)}`);
            const isSelected = this.selectedItems.findIndex(i => i.uniqueId === id) > -1;
            if (isSelected && thisItemElement) {
                return {
                    position: "absolute",
                    opacity: 1,
                    transition: "all, .5s",
                    height: thisItemElement.clientHeight,
                    width: thisItemElement.clientWidth,
                    top: thisItemElement.offsetTop,
                    left: thisItemElement.offsetLeft,
                    padding: 0
                }
            } else if (thisItemElement) {
                return {
                    position: "absolute",
                    transition: "all, .5s",
                    top: 0,
                    left: thisItemElement.clientWidth * -1,
                    opacity: 0,
                    padding: 0
                }
            } else {
                return {
                    position: "absolute",
                    transition: "all, .5s",
                    top: 0,
                    left: 0,
                    opacity: 0,
                    display: "none"
                }
            }
        } else {
            return {
                position: "absolute",
                transition: "all, .5s",
                top: 0,
                left: 0,
                opacity: 0,
                display: "none"
            }
        }
    };

    private _shouldUpdateSelectedItems = (selectedKeys: string[]) => {
        if (selectedKeys.length !== this.selectedItems.length) {
            return true;
        }
        const tempKeys = [];
        selectedKeys.forEach(key => {
            if (!this.selectedItems.find(i => i.uniqueId === key)) {
                tempKeys.push(key);
            }
        });
        return tempKeys.length > 0;
    };

    private _onSelectItems = (selectedItems: IButtonProps[]) => {
        this.props.items.forEach(i => {
            this.selectedItems = selectedItems;
            i.className = this.selectedItems.find(j => i.uniqueId === j.uniqueId) ? "is-selected" : "";
        });
        if (this.props.onChanged) {
            this.props.multiSelect
                ? this.props.onChanged(this.selectedItems)
                : this.props.onChanged(this.selectedItems[0]);
        }
        this.forceUpdate();
    };

    private _addToSelectedItems = (item: IButtonProps) => {
        if (this.props.multiSelect) {
            this.selectedItems.push(item);
        } else {
            this.selectedItems = [item];
        }
        this._onSelectItems(this.selectedItems);
    };

    private _removeFromSelectedItems = (item: IButtonProps) => {
        if (this.props.multiSelect) {
            const itemInSelectedOnes = this.selectedItems.find(i => i.uniqueId === item.uniqueId);
            const itemIndex = this.selectedItems.indexOf(itemInSelectedOnes);
            this.selectedItems.splice(itemIndex, 1);
        } else {
            return;
        }
        this._onSelectItems(this.selectedItems);

    };

    _isItemSelected = (item: IButtonProps) => this.selectedItems && this.selectedItems.find(i => item.uniqueId === i.uniqueId);

    render() {
        return <div ref={this._setRef} style={this.props.style}
                    role="radiogroup"
                    className={css(this.props.className, this._classNamePrefix)}
                    aria-labelledby={this.props.label}>
            {this.props.label ? <Label>{this.props.label}</Label> : null}
            {this.props.items.map((i, index) => {
                const isSelected = this.selectedItems.findIndex(item => item.uniqueId === i.uniqueId) > -1;
                const style = this._getStyle(i.uniqueId);
                const defaultButton = <DefaultButton key={`defaultBtn_${i.uniqueId}`} {...i}
                                                     aria-labelledby={i.text}
                                                     className={css(i.className, `${this._getItemClassName(i.uniqueId)}`)}
                                                     onClick={() => {
                                                         this._addToSelectedItems(i);
                                                     }}
                                                     aria-checked="false"/>;
                const primaryButton = <PrimaryButton key={`primaryBtn_${i.uniqueId}`}
                                                     {...i}
                                                     onClick={() => {
                                                         this._removeFromSelectedItems(i)
                                                     }}
                                                     className={css(`${this._classNamePrefix}--${i.uniqueId}-hover-element`, isSelected ? "is-selected" : "")}
                                                     style={style && this.props.transition ? style : {}}/>;

                if (this.props.transition) {
                    if (this.props.multiSelect) {
                        return <React.Fragment key={index}>
                            {defaultButton}
                            {this.props.multiSelect ? primaryButton : null}
                        </React.Fragment>
                    } else {
                        return defaultButton;
                    }
                } else {
                    return this._isItemSelected(i) ? primaryButton : defaultButton;
                }
            })}
            {(this.props.transition && !this.props.multiSelect && this.selectedItems[0])
                ? <PrimaryButton text={this.selectedItems[0].text}
                                 style={this._getStyle(this.selectedItems[0].uniqueId)}
                                 onClick={() => {
                                     this._removeFromSelectedItems(this.selectedItems[0])
                                 }}
                                 className={css(`${this._classNamePrefix}--${this.selectedItems[0].uniqueId}-hover-element`, "is-selected")}/>
                : null}

        </div>
    }
}

export {ButtonGroup as default, ButtonGroup, IButtonGroupProps}